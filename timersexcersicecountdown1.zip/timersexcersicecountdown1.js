function randomgame() {
	let i=0;
	let generado=0;
	while ( generado <0.75){
	let generado= Math.random();
		i++;
		console.log (generado+" menor .75");
	}
	return console.log ("intentos "+i);
console.log(generado+" mayor .75");}

  