function generateMeme() {
    event.preventDefault(); 

    const topLineText = document.getElementById("topLine").value;
    const bottomLineText = document.getElementById("bottomLine").value;
    const imageUrl = document.getElementById("imageUrl").value;
  
    // Create a new image element
    const image = new Image();
  
    image.onload = function () {
      const canvas = document.getElementById("memeCanvas");
      const context = canvas.getContext("2d");
  
      canvas.width = image.width;
      canvas.height = image.height;
      context.drawImage(image, 10, -10);
  
      // Set text properties
      context.font = "60px Impact";
      context.fillStyle = "white";
      context.strokeStyle = "black";
      context.lineWidth = 2;
      context.textAlign = "center";
  
      // Add top text
      context.fillText(topLineText, canvas.width / 2, 50);
      context.strokeText(topLineText, canvas.width / 2, 50);
  
      // Add bottom text
      context.fillText(bottomLineText, canvas.width / 2, canvas.height - 20);
      context.strokeText(bottomLineText, canvas.width / 2, canvas.height - 20);
    };
    // Set image source URL
    image.src = imageUrl;
  }
  