const todoForm = document.getElementById('todoForm');
const taskList = document.getElementById('taskList');
const tasksList = JSON.parse(localStorage.getItem('tasksList'));
let i=0;
 
// load saved tasks
// console.log(tasksList);

for (i=0; i<tasksList.length; i++ )
  {
  const listItem = document.createElement('li'); 
  const btnRemo = document.createElement("button"); btnRemo.innerText = "Remove";
  listItem.textContent = tasksList[i];
  listItem.classList.add('todo'); 
  taskList.appendChild(listItem);
  listItem.appendChild(btnRemo);
  taskInput.value = ''; 
  };
// remove task if needed and add mark task done
taskList.addEventListener('click' , function removeTask(event) {
 // console.log(event.target.tagName);
  if (event.target.tagName==='BUTTON') {
      event.target.parentElement.remove();
  }
  if (event.target.tagName==='LI') {
    event.target.style.textDecoration = "line-through";
}
});
// add task to the list
function addTask(event) {
    event.preventDefault(); 
    const taskInput = document.getElementById('taskInput');
    const task = taskInput.value;

    if (task) {
      // Create a new list item
      const listItem = document.createElement('li'); 
      const btnRemo = document.createElement("button"); btnRemo.innerText = "Remove";
      listItem.textContent = task;
      listItem.classList.add('todo'); 
      taskList.appendChild(listItem);
      tasksList.push(listItem.innerText);
      localStorage.setItem('tasksList',JSON.stringify(tasksList));
      listItem.appendChild(btnRemo);
      taskInput.value = '';
    }
  }
  // call add task form
  todoForm.addEventListener('submit', addTask);
  const remotask=document.getElementsByClassName('todo');
