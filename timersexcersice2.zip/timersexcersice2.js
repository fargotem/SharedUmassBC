function randomGame() {
	let i=0;
	let generado=0;
setInterval ( function() {
	let generado= Math.random();
		i++;
	if ( generado >0.75){
		return console.log ("intentos "+i);
		clearInterval;}
	}, 1000)
}